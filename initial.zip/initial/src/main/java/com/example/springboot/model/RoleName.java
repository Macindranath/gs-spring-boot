package com.example.springboot.model;

// RoleName enum representing the names of user roles in the system.
public enum RoleName {
    ROLE_MANAGER,
    ROLE_MEMBER
}