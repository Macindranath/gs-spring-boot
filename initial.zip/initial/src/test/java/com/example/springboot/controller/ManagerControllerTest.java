package com.example.springboot.controller;

import com.example.springboot.repository.ManagerRepository;
import com.example.springboot.repository.RoleRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc; // Importante
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.context.ApplicationContextAware;
import org.springframework.beans.BeansException;
import org.springframework.boot.SpringApplication;
import com.example.springboot.Application;
import org.springframework.context.ApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;


@WebMvcTest(ManagerController.class)
// QUESTA RIGA È IL TRUCCO: addFilters = false disattiva login e password per il test
@AutoConfigureMockMvc(addFilters = false) 
public class ManagerControllerTest implements ApplicationContextAware{

    @Autowired
    private MockMvc mockMvc;

    @MockBean private ManagerRepository managerRepository;
    @MockBean private RoleRepository roleRepository;
    @MockBean private PasswordEncoder passwordEncoder;

    @Override
    public void setApplicationContext(ApplicationContext context)
            throws BeansException
    {
        context = SpringApplication.run(Application.class);
    }

    @Test
    public void testShowManagerList() throws Exception {        
        // ACT & ASSERT
        mockMvc.perform(get("/manager")) 
                .andExpect(status().isOk()) // Ora darà 200 OK perché la sicurezza è spenta
                .andExpect(view().name("manager/list"));
    }


    @Test
    public void testShowCreateForm() throws Exception {
        // Testiamo anche la pagina di creazione
        mockMvc.perform(get("/manager-create"))
                .andExpect(status().isOk())
                .andExpect(view().name("manager/create"));
    }
}
