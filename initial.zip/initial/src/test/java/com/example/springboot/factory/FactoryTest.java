package com.example.springboot.factory;

import com.example.springboot.model.Manager;
import com.example.springboot.model.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FactoryTest {

    @Test
    public void testManagerFactory() {
        UserFactory factory = new ManagerFactory();
        User u = factory.getInstance();
        
        assertNotNull(u);
        assertTrue(u instanceof Manager); // Verifica che crei davvero un Manager
    }
    
    // Si possono aggiungere qui test simili per MemberFactory e TrainerFactory
}
