package com.example.springboot.service;

import com.example.springboot.model.Member;
import com.example.springboot.repository.MemberRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;

/**
 * Unit Test for MemberService.
 * Verifies that the service logic correctly delegates to the repository.
 */
@ExtendWith(MockitoExtension.class)
public class MemberServiceTest {

    // Mock the repository so we don't need a real database
    @Mock
    private MemberRepository memberRepository;

    // Inject the mock repository into the real MemberService
    @InjectMocks
    private MemberService memberService;

    /**
     * Test for getActiveMembers()
     * Expectation: The service should call repo.findByArchivedAtIsNull()
     */
    @Test
    public void testGetActiveMembers() {
        // --- 1. ARRANGE ---
        Member m1 = new Member();
        m1.setName("Active Member");
        List<Member> fakeList = Arrays.asList(m1);

        // Define behavior: When the repository is asked for active members, return our fake list
        when(memberRepository.findByArchivedAtIsNull()).thenReturn(fakeList);

        // --- 2. ACT ---
        List<Member> result = memberService.getActiveMembers();

        // --- 3. ASSERT ---
        assertEquals(1, result.size());
        assertEquals("Active Member", result.get(0).getName());

        // Verify that the correct repository method was called exactly once
        verify(memberRepository, times(1)).findByArchivedAtIsNull();
    }

    /**
     * Test for getArchivedMembers()
     * Expectation: The service should call repo.findByArchivedAtIsNotNull()
     */
    @Test
    public void testGetArchivedMembers() {
        // --- 1. ARRANGE ---
        Member m1 = new Member();
        m1.setName("Archived Member");
        List<Member> fakeList = Arrays.asList(m1);

        // Define behavior: When the repository is asked for archived members, return our fake list
        when(memberRepository.findByArchivedAtIsNotNull()).thenReturn(fakeList);

        // --- 2. ACT ---
        List<Member> result = memberService.getArchivedMembers();

        // --- 3. ASSERT ---
        assertEquals(1, result.size());
        assertEquals("Archived Member", result.get(0).getName());

        // Verify that the correct repository method was called exactly once
        verify(memberRepository, times(1)).findByArchivedAtIsNotNull();
    }
}