package com.example.springboot.service;

import com.example.springboot.model.Trainer;
import com.example.springboot.repository.TrainerRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;

/**
 * Unit Test for TrainerService.
 * Verifies that the service logic correctly delegates to the repository.
 */
@ExtendWith(MockitoExtension.class)
public class TrainerServiceTest {

    // Mock the repository so we don't need a real database
    @Mock
    private TrainerRepository trainerRepository;

    // Inject the mock repository into the real TrainerService
    @InjectMocks
    private TrainerService trainerService;

    /**
     * Test for getActiveTrainers()
     * Expectation: The service should call repo.findByArchivedAtIsNull()
     */
    @Test
    public void testGetActiveTrainers() {
        // --- 1. ARRANGE ---
        Trainer t1 = new Trainer();
        t1.setName("Active Trainer");
        List<Trainer> fakeList = Arrays.asList(t1);

        // Define behavior: When the repository is asked for active trainers, return our fake list
        when(trainerRepository.findByArchivedAtIsNull()).thenReturn(fakeList);

        // --- 2. ACT ---
        List<Trainer> result = trainerService.getActiveTrainers();

        // --- 3. ASSERT ---
        assertEquals(1, result.size());
        assertEquals("Active Trainer", result.get(0).getName());

        // Verify that the correct repository method was called exactly once
        verify(trainerRepository, times(1)).findByArchivedAtIsNull();
    }

    /**
     * Test for getArchivedTrainers()
     * Expectation: The service should call repo.findByArchivedAtIsNotNull()
     */
    @Test
    public void testGetArchivedTrainers() {
        // --- 1. ARRANGE ---
        Trainer t1 = new Trainer();
        t1.setName("Archived Trainer");
        List<Trainer> fakeList = Arrays.asList(t1);

        // Define behavior: When the repository is asked for archived trainers, return our fake list
        when(trainerRepository.findByArchivedAtIsNotNull()).thenReturn(fakeList);

        // --- 2. ACT ---
        List<Trainer> result = trainerService.getArchivedTrainers();

        // --- 3. ASSERT ---
        assertEquals(1, result.size());
        assertEquals("Archived Trainer", result.get(0).getName());

        // Verify that the correct repository method was called exactly once
        verify(trainerRepository, times(1)).findByArchivedAtIsNotNull();
    }
}
